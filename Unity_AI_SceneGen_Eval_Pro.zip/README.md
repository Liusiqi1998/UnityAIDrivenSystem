
# Unity AI SceneGen + Evaluation PRO

## Features
- JSON-driven scene generation
- Trajectory recording
- Danger zone detection
- Scoring system (stability + risk)
- Gizmos visualization
- CSV + auto report

## Usage
1. Put prefabs in Resources/Prefabs
2. Edit StreamingAssets/scene.json
3. Tools → Generate Scene
4. Play → move target
5. Press Export

## Output
CSV + Report in persistentDataPath
