
using UnityEngine;
using System.IO;
using System.Collections.Generic;

[System.Serializable]
public class SceneObjectData{
    public string prefab;
    public float[] position;
}
[System.Serializable]
public class SceneData{
    public List<SceneObjectData> objects;
}

public class SceneGenerator:MonoBehaviour{
    public void Generate(){
        string path = Path.Combine(Application.streamingAssetsPath,"scene.json");
        var data = JsonUtility.FromJson<SceneData>(File.ReadAllText(path));

        foreach(var obj in data.objects){
            var prefab = Resources.Load<GameObject>("Prefabs/"+obj.prefab);
            if(prefab==null){Debug.LogError(obj.prefab);continue;}
            Instantiate(prefab,new Vector3(obj.position[0],obj.position[1],obj.position[2]),Quaternion.identity);
        }
    }
}
