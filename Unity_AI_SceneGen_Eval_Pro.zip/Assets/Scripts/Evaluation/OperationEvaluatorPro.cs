
using UnityEngine;
using System.Collections.Generic;
using System.IO;

public class OperationEvaluatorPro:MonoBehaviour{
    public Transform target;
    public float interval=0.1f;
    public string dangerTag="Danger";

    private List<Vector3> path=new List<Vector3>();
    private int dangerCount=0;
    private float timer;

    void Update(){
        timer+=Time.deltaTime;
        if(timer>=interval){
            timer=0;
            path.Add(target.position);
        }
    }

    void OnTriggerEnter(Collider other){
        if(other.CompareTag(dangerTag)){
            dangerCount++;
        }
    }

    public void Export(){
        string p=Path.Combine(Application.persistentDataPath,"result.csv");
        using(StreamWriter sw=new StreamWriter(p)){
            sw.WriteLine("x,y,z");
            foreach(var v in path) sw.WriteLine(v.x+","+v.y+","+v.z);
        }

        float stability=CalcStability();
        float score=100 - dangerCount*10 - (100-stability);

        File.WriteAllText(Path.Combine(Application.persistentDataPath,"report.txt"),
        "Stability:"+stability+"\nDanger:"+dangerCount+"\nScore:"+score);

        Debug.Log("Export Done");
    }

    float CalcStability(){
        float sum=0;
        for(int i=1;i<path.Count;i++){
            sum+=Vector3.Distance(path[i],path[i-1]);
        }
        return Mathf.Clamp(100 - sum,0,100);
    }

    void OnDrawGizmos(){
        Gizmos.color=Color.green;
        for(int i=1;i<path.Count;i++){
            Gizmos.DrawLine(path[i-1],path[i]);
        }
    }
}
